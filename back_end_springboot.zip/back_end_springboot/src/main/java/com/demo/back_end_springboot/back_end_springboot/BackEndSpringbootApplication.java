package com.demo.back_end_springboot.back_end_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndSpringbootApplication.class, args);
	}

}
