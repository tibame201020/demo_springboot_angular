package com.demo.back_end_springboot.back_end_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
